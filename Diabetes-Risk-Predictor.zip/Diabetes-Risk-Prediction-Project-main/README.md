# Diabetes Risk Predictor

An end-to-end machine learning project with a web dashboard. Enter eight health measurements and get an estimated probability of diabetes, plus a plain-language breakdown of which measurements pushed the estimate up or down. Upload a CSV to screen many patients at once.

> Educational project. Not a medical device and not medical advice.

![Single reading](docs/screenshots/single-reading.png)

## What it does

- **Single reading:** risk gauge with low / moderate / high bands and a "what moved the estimate" chart that compares each measurement with the typical training value.
- **Batch screening:** drop in a CSV and get a summary, a risk distribution, the highest-risk patients, and a CSV export of every prediction.
- **About the model:** test and cross-validated ROC AUC, F1, global SHAP and permutation-importance figures, and the dataset's known limitations.
- **Reproducible pipeline:** scripts for loading, cleaning, EDA, statistics, training (logistic regression, random forest, gradient boosting, XGBoost), evaluation and explainability.

| Batch screening | About the model |
| --- | --- |
| ![Batch](docs/screenshots/batch-screening.png) | ![Model](docs/screenshots/about-the-model.png) |

## Run it locally

Requires Python 3.10 or newer.

```bash
python -m venv venv
venv\Scripts\activate          # Windows (macOS/Linux: source venv/bin/activate)
pip install -r requirements.txt
python -m src.dashboard.app
```

Open <http://127.0.0.1:5000>. In VS Code you can also press **F5** (a launch config is included in `.vscode/`).

**Retrain the model** (recommended if your scikit-learn version differs from the one used to save the bundled models):

```bash
python src/model_training.py --data data/diabetes.csv --model gb --out_dir reports
```

Or run the whole pipeline with `python main.py`.

## Project layout

```
data/                  Pima Indians Diabetes dataset
src/
  data_*.py, statistical_analysis.py   loading, cleaning, EDA, tests
  model_training.py, model_evaluation.py, model_explainability_interpretability.py
  dashboard/
    app.py             Flask routes (/, /predict, /predict_batch, /health, ...)
    predict.py         model loading, predictions, local explanations
  templates/index.html
  static/css/app.css, static/js/app.js
reports/               metrics, figures, trained models
tests/                 pytest suite
```

## Design and engineering notes

- **Resilient model loading.** If a saved model cannot be unpickled (for example, a scikit-learn version mismatch), the app tries the other saved models, then trains a small logistic-regression fallback from `data/diabetes.csv`, instead of crashing.
- **Model-agnostic local explanations.** For one patient, each feature is swapped for the training median and the change in predicted probability is reported. It works with any scikit-learn classifier and needs no extra dependencies.
- **Accessible UI.** Keyboard-navigable tabs, labelled inputs with inline validation, visible focus, dark-mode and reduced-motion support, and colour used only for risk bands.
- **Tests.** `pytest -q` covers the pipeline, API endpoints, risk bands, explanations and the model-loading fallback.

## Limitations

The dataset has 768 women aged 21+ of Pima Indian heritage, so results may not generalise. In the raw data a 0 for glucose, blood pressure, skin thickness, insulin or BMI usually means "not measured".

## Credits and license

Based on the open-source [Diabetes Risk Prediction Project](https://github.com/AAdewunmi) by **Adrian Adewunmi** (MIT). Interface redesign, local explanations, batch export, resilient model loading and tests added by **<YOUR NAME>**. Dataset: National Institute of Diabetes and Digestive and Kidney Diseases.

Released under the [MIT License](LICENSE), which keeps the original copyright notice.
