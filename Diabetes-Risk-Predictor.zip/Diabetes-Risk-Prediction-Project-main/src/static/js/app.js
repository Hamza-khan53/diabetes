/*
 * src/static/js/app.js
 * Behaviour for the Diabetes Risk dashboard: tabs, validation, gauge,
 * driver bars, batch screening, CSV export.
 */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const css = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

  const BANDS = {
    low:      { label: 'Low risk',      cls: 'is-low',      max: 0.30 },
    moderate: { label: 'Moderate risk', cls: 'is-moderate', max: 0.60 },
    high:     { label: 'High risk',     cls: 'is-high',     max: 1.01 },
  };

  function bandOf(p) {
    return p < 0.30 ? 'low' : p < 0.60 ? 'moderate' : 'high';
  }

  const PLAIN = {
    low: 'Based on these measurements, the model sees a lower chance of diabetes than most profiles in its training data.',
    moderate: 'These measurements sit in a middle range. A routine check-up would help clarify the picture.',
    high: 'These measurements resemble profiles that were often diagnosed with diabetes. Consider speaking with a clinician.',
  };

  const LABELS = {
    Pregnancies: 'Pregnancies', Glucose: 'Glucose', BloodPressure: 'Blood pressure',
    SkinThickness: 'Skin thickness', Insulin: 'Insulin', BMI: 'BMI',
    DiabetesPedigreeFunction: 'Family-history score', Age: 'Age',
  };

  const PRESETS = {
    lower:  { Pregnancies: 1, Glucose: 88, BloodPressure: 64, SkinThickness: 22, Insulin: 70, BMI: 24.1, DiabetesPedigreeFunction: 0.25, Age: 26 },
    higher: { Pregnancies: 6, Glucose: 168, BloodPressure: 84, SkinThickness: 36, Insulin: 220, BMI: 38.4, DiabetesPedigreeFunction: 0.95, Age: 52 },
  };

  const fmt = (n, d = 1) => Number(n).toLocaleString(undefined, { maximumFractionDigits: d });
  const pctText = (p) => (p * 100).toFixed(1) + '%';

  function showNotice(el, msg) {
    el.textContent = msg;
    el.hidden = !msg;
  }

  // ---------------------------------------------------------------- Tabs
  const tabs = Array.from(document.querySelectorAll('.tab'));
  function selectTab(tab) {
    tabs.forEach((t) => {
      const on = t === tab;
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
      $(t.getAttribute('aria-controls')).hidden = !on;
    });
  }
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => selectTab(t));
    t.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      const next = tabs[(i + (e.key === 'ArrowRight' ? 1 : tabs.length - 1)) % tabs.length];
      selectTab(next);
      next.focus();
    });
  });

  // --------------------------------------------------------------- Gauge
  const CX = 120, CY = 120, R = 96;
  function pointAt(frac) {
    const a = Math.PI * (1 - frac); // 0 -> left, 1 -> right
    return [CX + R * Math.cos(a), CY - R * Math.sin(a)];
  }
  function arc(from, to) {
    const [x1, y1] = pointAt(from);
    const [x2, y2] = pointAt(to);
    return `M ${x1.toFixed(2)} ${y1.toFixed(2)} A ${R} ${R} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`;
  }
  $('arcLow').setAttribute('d', arc(0, 0.30));
  $('arcModerate').setAttribute('d', arc(0.30, 0.60));
  $('arcHigh').setAttribute('d', arc(0.60, 1));

  function setGauge(p) {
    $('needle').style.transform = `rotate(${(-90 + p * 180).toFixed(1)}deg)`;
  }

  function resetReading() {
    setGauge(0);
    $('pct').textContent = '--';
    const band = $('band');
    band.className = 'band';
    band.textContent = 'Not calculated';
    $('plain').textContent = 'Press “Calculate risk” to see an estimate for these measurements.';
    $('drivers').hidden = true;
    showNotice($('singleError'), '');
  }

  // ------------------------------------------------------ Single reading
  const form = $('singleForm');
  const inputs = Array.from(form.querySelectorAll('input'));

  function validate() {
    let ok = true;
    inputs.forEach((inp) => {
      const err = $('e-' + inp.name);
      const v = inp.value.trim();
      const n = Number(v);
      const lo = Number(inp.min), hi = Number(inp.max);
      let msg = '';
      if (v === '' || Number.isNaN(n)) msg = 'Enter a number.';
      else if (n < lo || n > hi) msg = `Use a value from ${lo} to ${hi}.`;
      inp.setAttribute('aria-invalid', msg ? 'true' : 'false');
      err.textContent = msg;
      if (msg) ok = false;
    });
    return ok;
  }

  inputs.forEach((inp) => inp.addEventListener('input', () => {
    if (inp.getAttribute('aria-invalid') === 'true') validate();
  }));

  function fillForm(values) {
    inputs.forEach((inp) => {
      if (values[inp.name] !== undefined) inp.value = values[inp.name];
      inp.setAttribute('aria-invalid', 'false');
      $('e-' + inp.name).textContent = '';
    });
  }

  document.querySelectorAll('[data-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      fillForm(PRESETS[btn.dataset.preset]);
      form.requestSubmit();
    });
  });

  $('singleReset').addEventListener('click', () => {
    const defaults = {};
    inputs.forEach((inp) => { defaults[inp.name] = inp.dataset.default; });
    fillForm(defaults);
    resetReading();
  });

  function renderDrivers(drivers) {
    const box = $('drivers');
    const list = $('driverList');
    list.innerHTML = '';
    if (!drivers || !drivers.length) { box.hidden = true; return; }
    const top = drivers.slice(0, 6);
    const maxAbs = Math.max(...top.map((d) => Math.abs(d.impact)), 0.01);
    top.forEach((d) => {
      const li = document.createElement('li');
      li.className = 'driver';
      const width = Math.min(50, (Math.abs(d.impact) / maxAbs) * 50);
      const pts = d.impact * 100;
      const sign = pts > 0 ? '+' : pts < 0 ? '−' : '';
      li.innerHTML = `
        <div class="name"><strong></strong><span></span></div>
        <div class="axis" role="img"><span class="fill ${d.impact >= 0 ? 'up' : 'down'}" style="width:${width}%"></span></div>
        <div class="delta"></div>`;
      li.querySelector('strong').textContent = LABELS[d.feature] || d.feature;
      li.querySelector('.name span').textContent = `${fmt(d.value, 2)} vs typical ${fmt(d.typical, 2)}`;
      li.querySelector('.axis').setAttribute('aria-label',
        `${LABELS[d.feature] || d.feature}: ${pts >= 0 ? 'raises' : 'lowers'} risk by ${Math.abs(pts).toFixed(1)} points`);
      li.querySelector('.delta').textContent = `${sign}${Math.abs(pts).toFixed(1)}`;
      list.appendChild(li);
    });
    box.hidden = false;
  }

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    showNotice($('singleError'), '');
    if (!validate()) {
      showNotice($('singleError'), 'Fix the highlighted fields and try again.');
      return;
    }
    const payload = {};
    inputs.forEach((inp) => { payload[inp.name] = Number(inp.value); });

    const btn = $('singleSubmit');
    btn.disabled = true;
    try {
      const res = await fetch('/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const j = await res.json();
      if (!j.ok) throw new Error(j.error || 'The prediction could not be completed.');
      const r = j.result || {};
      if (r.probability == null) throw new Error('The model did not return a probability.');

      const p = r.probability;
      const key = r.risk_band || bandOf(p);
      setGauge(p);
      $('pct').textContent = pctText(p);
      const band = $('band');
      band.className = 'band ' + BANDS[key].cls;
      band.textContent = BANDS[key].label;
      $('plain').textContent = PLAIN[key];
      renderDrivers(r.drivers);
    } catch (e) {
      showNotice($('singleError'), e.message);
    } finally {
      btn.disabled = false;
    }
  });

  // ------------------------------------------------------ Batch screening
  const fileInput = $('batchCsvInput');
  const drop = $('drop');
  let batchChart = null;
  let lastRecords = [];

  function setPickedFile(file) {
    $('dropTitle').textContent = file ? file.name : 'Choose a CSV file or drop it here';
    $('dropSub').textContent = file ? `${(file.size / 1024).toFixed(1)} KB, ready to run` : 'Up to 5 MB';
  }

  fileInput.addEventListener('change', () => setPickedFile(fileInput.files[0]));
  ['dragenter', 'dragover'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.add('is-over'); }));
  ['dragleave', 'drop'].forEach((n) => drop.addEventListener(n, (e) => { e.preventDefault(); drop.classList.remove('is-over'); }));
  drop.addEventListener('drop', (e) => {
    if (e.dataTransfer.files.length) {
      fileInput.files = e.dataTransfer.files;
      setPickedFile(fileInput.files[0]);
    }
  });

  function toCsv(records) {
    if (!records.length) return '';
    const cols = Object.keys(records[0]);
    const esc = (v) => {
      const s = v == null ? '' : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    return [cols.join(',')].concat(records.map((r) => cols.map((c) => esc(r[c])).join(','))).join('\n');
  }

  function renderHistogram(hist) {
    const edges = (hist && hist.bin_edges) || [];
    const counts = (hist && hist.counts) || [];
    const labels = [], colors = [];
    for (let i = 0; i + 1 < edges.length; i++) {
      labels.push(`${Math.round(edges[i] * 100)}–${Math.round(edges[i + 1] * 100)}%`);
      colors.push(css('--' + bandOf((edges[i] + edges[i + 1]) / 2)));
    }
    if (batchChart) batchChart.destroy();
    const text = css('--ink-soft');
    batchChart = new Chart($('batchHistCanvas').getContext('2d'), {
      type: 'bar',
      data: { labels, datasets: [{ label: 'Patients', data: counts, backgroundColor: colors, borderRadius: 3 }] },
      options: {
        maintainAspectRatio: false,
        plugins: { legend: { display: false }, title: { display: true, text: 'How predicted risk is distributed', color: text } },
        scales: {
          x: { ticks: { color: text, maxRotation: 0, autoSkip: true }, grid: { display: false }, title: { display: true, text: 'Predicted risk', color: text } },
          y: { beginAtZero: true, ticks: { precision: 0, color: text }, grid: { color: css('--line') }, title: { display: true, text: 'Patients', color: text } },
        },
      },
    });
  }

  function renderMix(records) {
    const counts = { low: 0, moderate: 0, high: 0 };
    records.forEach((r) => { if (r.probability != null) counts[bandOf(r.probability)]++; });
    const total = records.length || 1;
    $('mix').innerHTML = ['low', 'moderate', 'high']
      .map((k) => `<span class="m-${k}" style="width:${(counts[k] / total) * 100}%"></span>`).join('');
    $('mixLegend').innerHTML = ['low', 'moderate', 'high']
      .map((k) => `<span><i class="swatch" style="background:var(--${k})"></i>${BANDS[k].label}: ${counts[k]}</span>`).join('');
    return counts;
  }

  function renderTable(records) {
    const feats = Object.keys(LABELS);
    const top = records.filter((r) => r.probability != null)
      .sort((a, b) => b.probability - a.probability).slice(0, 10);
    $('tableHint').textContent = `Showing the ${top.length} highest of ${records.length} patients. Download the CSV for every row.`;
    const head = '<tr><th>Risk</th><th>Band</th>' + feats.map((f) => `<th>${LABELS[f]}</th>`).join('') + '</tr>';
    const body = top.map((r) => {
      const k = bandOf(r.probability);
      return `<tr><td>${pctText(r.probability)}</td><td><span class="pill ${BANDS[k].cls}">${BANDS[k].label.split(' ')[0]}</span></td>` +
        feats.map((f) => `<td>${r[f] == null ? '' : fmt(r[f], 3)}</td>`).join('') + '</tr>';
    }).join('');
    $('batchTable').innerHTML = head + body;
  }

  function renderFiles(files) {
    const ul = $('batchFilesList');
    ul.innerHTML = '';
    if (!files || !files.length) { ul.innerHTML = '<li>No files saved yet.</li>'; return; }
    files.slice(0, 20).forEach((f) => {
      const li = document.createElement('li');
      const a = document.createElement('a');
      a.href = `/reports/explain/${encodeURIComponent(f.filename)}?t=${f.mtime || Date.now()}`;
      a.textContent = f.filename;
      a.target = '_blank';
      a.rel = 'noopener';
      li.appendChild(a);
      ul.appendChild(li);
    });
  }

  async function runBatch(file) {
    showNotice($('batchError'), '');
    if (!file) { showNotice($('batchError'), 'Choose a CSV file first.'); return; }
    if (!/\.csv$/i.test(file.name)) { showNotice($('batchError'), 'Only .csv files are supported.'); return; }

    const fd = new FormData();
    fd.append('file', file);
    const btn = $('batchUploadBtn');
    btn.disabled = true;
    try {
      const res = await fetch('/predict_batch', { method: 'POST', body: fd });
      const j = await res.json();
      if (!j.ok) throw new Error(j.error || 'Screening failed.');
      const r = j.result || {};
      lastRecords = r.predictions || [];

      $('sRows').textContent = fmt(r.n_rows || 0, 0);
      $('sAvg').textContent = r.mean_probability != null ? pctText(r.mean_probability) : 'n/a';
      const counts = renderMix(lastRecords);
      $('sHigh').textContent = fmt(counts.high, 0);
      renderHistogram(r.histogram);
      renderTable(lastRecords);
      renderFiles(r.explanation_files);
      $('batchResult').hidden = false;
      $('batchTableBox').hidden = false;
    } catch (e) {
      showNotice($('batchError'), e.message);
    } finally {
      btn.disabled = false;
    }
  }

  $('batchForm').addEventListener('submit', (ev) => {
    ev.preventDefault();
    runBatch(fileInput.files[0]);
  });

  $('batchSample').addEventListener('click', async () => {
    try {
      const res = await fetch('/static/sample_patients.csv');
      const blob = await res.blob();
      const file = new File([blob], 'sample_patients.csv', { type: 'text/csv' });
      const dt = new DataTransfer();
      dt.items.add(file);
      fileInput.files = dt.files;
      setPickedFile(file);
      runBatch(file);
    } catch (e) {
      showNotice($('batchError'), 'Could not load the sample file.');
    }
  });

  $('batchResetBtn').addEventListener('click', () => {
    fileInput.value = '';
    setPickedFile(null);
    if (batchChart) { batchChart.destroy(); batchChart = null; }
    lastRecords = [];
    $('batchResult').hidden = true;
    $('batchTableBox').hidden = true;
    showNotice($('batchError'), '');
  });

  $('downloadCsv').addEventListener('click', () => {
    const blob = new Blob([toCsv(lastRecords)], { type: 'text/csv' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'diabetes_risk_predictions.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(a.href);
  });

  resetReading();
})();
