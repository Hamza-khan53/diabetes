"""
tests/test_dashboard_features.py

Tests for features added on top of the original dashboard: risk bands,
local drivers, health check, API alias and resilient model loading.
"""

import joblib

from dashboard.predict import ModelWrapper, risk_band

PAYLOAD = {
    "Pregnancies": 6,
    "Glucose": 168,
    "BloodPressure": 84,
    "SkinThickness": 36,
    "Insulin": 220,
    "BMI": 38.4,
    "DiabetesPedigreeFunction": 0.95,
    "Age": 52,
}


def test_risk_band_thresholds():
    assert risk_band(None) is None
    assert risk_band(0.10) == "low"
    assert risk_band(0.30) == "moderate"
    assert risk_band(0.59) == "moderate"
    assert risk_band(0.60) == "high"


def test_predict_returns_band_and_drivers(client):
    body = client.post("/predict", json=PAYLOAD).get_json()
    assert body["ok"] is True
    result = body["result"]
    assert result["risk_band"] in {"low", "moderate", "high"}
    drivers = result["drivers"]
    assert drivers, "expected at least one driver"
    assert {"feature", "value", "typical", "impact"} <= set(drivers[0])
    impacts = [abs(d["impact"]) for d in drivers]
    assert impacts == sorted(impacts, reverse=True)


def test_health_endpoint(client):
    assert client.get("/health").get_json() == {"ok": True}


def test_explain_files_alias(client):
    assert client.get("/api/explain_files").get_json()["ok"] is True
    assert client.get("/api_explain_files").get_json()["ok"] is True


def test_wrapper_reports_model_info(saved_model_path):
    info = ModelWrapper(saved_model_path).get_model_info()
    assert info["algorithm"] == "LogisticRegression"


def test_wrapper_falls_back_when_model_cannot_load(tmp_path, monkeypatch):
    """A corrupt/incompatible artifact must not stop the app from starting."""
    import dashboard.predict as predict

    bad = tmp_path / "broken_best.joblib"
    joblib.dump({"not": "a model"}, bad)
    monkeypatch.setattr(predict, "list_model_candidates", lambda: [str(bad)])
    monkeypatch.setattr(
        predict.joblib, "load", lambda *_a, **_k: (_ for _ in ()).throw(ImportError("x"))
    )
    wrapper = ModelWrapper(None)
    assert wrapper.model is not None
    assert "fallback" in wrapper.model_path
    assert wrapper.load_note
